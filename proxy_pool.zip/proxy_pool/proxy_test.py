# -*- coding: utf-8 -*-
# !/usr/bin/env python

from handler.proxyHandler import ProxyHandler


def get():
    https = False
    proxy_handler = ProxyHandler()
    proxy = proxy_handler.get()
    return proxy.to_dict if proxy else {"code": 0, "src": "no proxy"}


if __name__ == "__main__":
    print(get())
